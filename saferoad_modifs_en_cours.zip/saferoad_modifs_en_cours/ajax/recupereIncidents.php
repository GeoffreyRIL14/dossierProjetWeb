<?php 
require '../modele.php';
session_start();
$idUser = $_SESSION['idUser'];
$distanceA = getSeuilDistanceMax(1) ;
$distance = intval($distanceA[0]);
$incidents = getIncident(43.5824367,3.8760508, $distance);
$incidentsToHide = getHidden($idUser);
$chaineJson = "";

//var_dump($incidents, $incidentsToHide);die;

foreach ($incidents as $incident) {
	$chaineJson .= implode(",",$incident);
	foreach ($incidentsToHide as $key => $incidentToHide) {
		if(in_array($incident['idIncident'], $incidentToHide))
			$chaineJson .= "," . "Hide";
	}
	$chaineJson .= "/";
}

echo $chaineJson;