<?php 
require '../modele.php';
$incidents = getTypesIncident();
echo $incidents;